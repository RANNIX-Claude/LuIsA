// ============================================================================
// LIGIA v2.0 - Netlify Function: Claude API Integration
// Maneja: Dictaciones, análisis de estudios, traducciones, chat con IA
// ============================================================================

const Anthropic = require('@anthropic-ai/sdk');

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// ── HANDLER PRINCIPAL ────────────────────────────────────────────────────
exports.handler = async (event) => {
  // Solo POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: 'Método no permitido' })
    };
  }

  try {
    const { type = 'dictation', payload } = JSON.parse(event.body);

    let response;

    switch(type) {
      case 'dictation':
        response = await procesarDictacion(payload);
        break;
      case 'lab-analysis':
        response = await analizarEstudio(payload);
        break;
      case 'translate':
        response = await traducir(payload);
        break;
      case 'chat':
        response = await chatLigia(payload);
        break;
      case 'extraction':
        response = await extraerDatos(payload);
        break;
      default:
        return {
          statusCode: 400,
          body: JSON.stringify({ error: 'Tipo de solicitud desconocido' })
        };
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(response)
    };

  } catch (error) {
    console.error('Error en Claude API:', error);
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message || 'Error procesando solicitud',
        type: error.constructor.name
      })
    };
  }
};

// ── 1. PROCESAR DICTACIÓN MÉDICA ─────────────────────────────────────────
async function procesarDictacion(payload) {
  const { texto, bloque = 'padecimiento' } = payload;

  if (!texto?.trim()) {
    throw new Error('Texto vacío');
  }

  const prompts = {
    antecedentes: `Eres asistente médico especializado. Analiza esta dictación de antecedentes médicos y extrae:
- Antecedentes heredofamiliares (diabetes, hipertensión, cancer, cardiopatía, tuberculosis)
- Antecedentes patológicos (enfermedades crónicas, cirugías, hospitalizaciones)
- Hábitos (tabaquismo, alcohol, drogas)
- Alergias a medicamentos

Responde SOLO con JSON válido, sin markdown:
{
  "ahf": { "diabetes": bool, "hipertension": bool, ... },
  "app": { "enfermedades_cronicas": [...], "cirugias": [...] },
  "habitos": { "tabaquismo": { "activo": bool, "cigarros_dia": int }, ... },
  "alergias": [...]
}`,

    padecimiento: `Eres asistente médico. Extrae del texto:
- Motivo de consulta
- Tiempo de evolución
- Intensidad (leve/moderada/severa)
- Características del síntoma
- Síntomas asociados
- Factores que lo mejoran/empeoran

Responde SOLO JSON:
{
  "motivo": "...",
  "tiempo_evolucion": "...",
  "intensidad": "...",
  "caracteristicas": "...",
  "sintomas_asociados": [...],
  "mejora": "...",
  "empeora": "..."
}`,

    signos_vitales: `Extrae SOLO números de signos vitales del texto:
{
  "ta_sistolica": num,
  "ta_diastolica": num,
  "fc": num,
  "fr": num,
  "temperatura": num,
  "sao2": num,
  "peso": num,
  "talla": num,
  "imc": num (calcular si hay peso/talla)
}
Si falta un valor, omite la clave.`,

    diagnostico: `Extrae diagnósticos médicos con código CIE-10 si es posible:
{
  "diagnosticos": [
    { "nombre": "...", "codigo_cie10": "..." },
    ...
  ],
  "diagnosticos_diferenciales": [
    { "nombre": "...", "probabilidad": 0.8 }
  ]
}`,

    tratamiento: `Extrae medicamentos, dosis, frecuencia, duración:
{
  "medicamentos": [
    {
      "nombre": "...",
      "dosis": "...",
      "via": "oral/iv/im/sc/topica",
      "frecuencia": "cada 6 horas/diarias/...",
      "duracion": "días/semanas"
    }
  ],
  "indicaciones": "...",
  "proxima_cita": "días"
}`
  };

  const systemPrompt = prompts[bloque] || prompts.padecimiento;

  const message = await client.messages.create({
    model: 'claude-opus-4-1',
    max_tokens: 2000,
    system: systemPrompt,
    messages: [
      {
        role: 'user',
        content: `Bloque: ${bloque}\n\nTexto:\n"${texto}"`
      }
    ]
  });

  const responseText = message.content[0].text;
  const jsonMatch = responseText.match(/\{[\s\S]*\}/);

  if (!jsonMatch) {
    throw new Error('No se pudo extraer JSON de la respuesta');
  }

  const resultado = JSON.parse(jsonMatch[0]);

  return {
    success: true,
    bloque,
    resultado,
    usage: {
      input_tokens: message.usage.input_tokens,
      output_tokens: message.usage.output_tokens
    }
  };
}

// ── 2. ANALIZAR REPORTES DE LABORATORIO ──────────────────────────────────
async function analizarEstudio(payload) {
  const { texto, tipo_estudio = 'general' } = payload;

  const message = await client.messages.create({
    model: 'claude-opus-4-1',
    max_tokens: 3000,
    system: `Eres experto patólogo/bioquímico. Analiza reportes de laboratorio.
Retorna SOLO JSON con:
{
  "valores": [
    {
      "parametro": "Hemoglobina",
      "valor": 14.5,
      "unidad": "g/dL",
      "rango_normal": "12.0-17.5",
      "estado": "normal/alto/bajo/critico",
      "interpretacion": "..."
    }
  ],
  "hallazgos_importantes": [...],
  "diagnosticos_sugeridos": [...],
  "estudios_complementarios_recomendados": [...],
  "urgencia": "routine/moderada/alta/critica"
}`,
    messages: [
      {
        role: 'user',
        content: `Tipo de estudio: ${tipo_estudio}\n\nReporte:\n${texto}`
      }
    ]
  });

  const responseText = message.content[0].text;
  const jsonMatch = responseText.match(/\{[\s\S]*\}/);

  if (!jsonMatch) {
    throw new Error('No se pudo procesar el reporte');
  }

  return {
    success: true,
    tipo_estudio,
    analisis: JSON.parse(jsonMatch[0]),
    usage: {
      input_tokens: message.usage.input_tokens,
      output_tokens: message.usage.output_tokens
    }
  };
}

// ── 3. TRADUCIR DATOS A MÚLTIPLES IDIOMAS ────────────────────────────────
async function traducir(payload) {
  const { texto, idiomas = ['en', 'fr', 'de'] } = payload;

  const idiomas_map = {
    es: 'Español',
    en: 'English',
    de: 'Deutsch',
    fr: 'Français',
    pt: 'Português',
    it: 'Italiano',
    zh: '中文'
  };

  const message = await client.messages.create({
    model: 'claude-opus-4-1',
    max_tokens: 2000,
    system: 'Eres traductor médico profesional. Traduce manteniendo terminología clínica exacta.',
    messages: [
      {
        role: 'user',
        content: `Traduce el siguiente texto médico a: ${idiomas.map(i => idiomas_map[i]).join(', ')}\n\nTexto:\n"${texto}"\n\nRetorna JSON: { "es": "...", "en": "...", "fr": "...", etc }`
      }
    ]
  });

  const responseText = message.content[0].text;
  const jsonMatch = responseText.match(/\{[\s\S]*\}/);

  return {
    success: true,
    idiomas_solicitados: idiomas,
    traducciones: jsonMatch ? JSON.parse(jsonMatch[0]) : { error: 'No se pudo traducir' },
    usage: {
      input_tokens: message.usage.input_tokens,
      output_tokens: message.usage.output_tokens
    }
  };
}

// ── 4. CHAT CON LIGIA (IA ASISTENTE) ─────────────────────────────────────
async function chatLigia(payload) {
  const { mensaje, contexto_paciente = {}, historial = [] } = payload;

  const contextoStr = Object.entries(contexto_paciente)
    .filter(([_, v]) => v)
    .map(([k, v]) => `${k}: ${v}`)
    .join('\n');

  const systemPrompt = `Eres LIGIA, asistente médico inteligente de LIGIA v2.0.
Eres amable, profesional, y siempre priorizar la seguridad del paciente.
Nunca diagnosticas — solo sugiere buscar atención médica si es grave.
Responde en el idioma del usuario.

Contexto del paciente (si existe):
${contextoStr || 'Sin datos del paciente'}

Responde siempre de forma clara, empática y en máximo 200 palabras.`;

  const messages = [
    ...historial.slice(-10).map(m => ({
      role: m.role,
      content: m.content
    })),
    {
      role: 'user',
      content: mensaje
    }
  ];

  const message = await client.messages.create({
    model: 'claude-opus-4-1',
    max_tokens: 500,
    system: systemPrompt,
    messages
  });

  const respuesta = message.content[0].text;

  return {
    success: true,
    respuesta,
    historico: [
      ...historial,
      { role: 'user', content: mensaje },
      { role: 'assistant', content: respuesta }
    ],
    usage: {
      input_tokens: message.usage.input_tokens,
      output_tokens: message.usage.output_tokens
    }
  };
}

// ── 5. EXTRACCIÓN DE DATOS GENÉRICA ──────────────────────────────────────
async function extraerDatos(payload) {
  const { texto, schema = {} } = payload;

  const schemaStr = Object.entries(schema)
    .map(([key, desc]) => `  - ${key}: ${desc}`)
    .join('\n');

  const message = await client.messages.create({
    model: 'claude-opus-4-1',
    max_tokens: 2000,
    system: `Eres asistente de extracción de datos. Extrae información del texto según este schema:
${schemaStr}

Retorna SOLO JSON válido con los campos solicitados. Si no encuentras un valor, usa null.`,
    messages: [
      {
        role: 'user',
        content: `Texto:\n${texto}`
      }
    ]
  });

  const responseText = message.content[0].text;
  const jsonMatch = responseText.match(/\{[\s\S]*\}/);

  return {
    success: true,
    datos: jsonMatch ? JSON.parse(jsonMatch[0]) : { error: 'No se pudo extraer' },
    usage: {
      input_tokens: message.usage.input_tokens,
      output_tokens: message.usage.output_tokens
    }
  };
}
